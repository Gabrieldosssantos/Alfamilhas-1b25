const express = require('express')
const expHandlebars = require('express-handlebars')
const path = require('path')

const db = require('./db/conexao')
const bodyParser = require('body-parser')


let aplicacao = express();

aplicacao.use(bodyParser.urlencoded({ extended: false }))

//Conf. Handlebars
aplicacao.set('views', path.join(__dirname, 'views'))

aplicacao.engine('handlebars', expHandlebars.engine())

aplicacao.set('view engine', 'handlebars')

aplicacao.use(
    express.static(path.join(__dirname, 'public'))
)


db.authenticate()
    .then(() => {//deu certo
        console.log('conecto no banco')
    })
    .catch(erro => {
        console.log("Deu erro: ", erro)
    })

//http://localhost:8000/
aplicacao.get('/', (requisicao, resposta) => {
    console.log('Principal')
    resposta.render('index')
})

aplicacao.get('/filmes/cadastro', (requisicao, resposta) => {
    resposta.render('cadastro')
})

aplicacao.use('/categoria', require('./routes/categoria'))

aplicacao.listen(8000, () => {
    console.log('Inicioou o servidor')
})