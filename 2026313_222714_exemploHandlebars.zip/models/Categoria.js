const Sequilize = require('sequelize')
const db = require('./../db/conexao')

const Categoria = db.define('categoria', {
    nome: {
        type: Sequilize.STRING
    }
})

module.exports = Categoria